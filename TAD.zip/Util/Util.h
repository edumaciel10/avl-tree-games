#ifndef UTIL_H
#define UTIL_H

#define TRUE 1
#define FALSE 0
typedef int boolean;

void boolean_print(boolean boolPrint);

char *readLine();

#endif //UTIL_H
